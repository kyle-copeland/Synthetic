# Synthetic

#### Leveling and creating art while browsing the interweb

- Earn experience for each page visited
- Watch your character grow as you gain experience


Created by Kyle Copeland (https://github.com/kyle-copeland)